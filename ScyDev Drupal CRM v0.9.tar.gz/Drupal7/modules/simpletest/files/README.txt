
These files are use in some tests that upload files or other operations were
a file is useful. These files are copied to the files directory as specified
in the site settings. Other tests files are generated in order to save space.
